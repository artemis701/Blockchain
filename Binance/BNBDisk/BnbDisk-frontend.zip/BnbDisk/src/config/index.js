export const BSC_BLOCK_TIME = 3

const MAINNET = 56
const TESTNET = 97

export const BASE_BSC_SCAN_URLS = {
    [MAINNET] : 'https://bscscan.com',
    [TESTNET] : 'https://testnet.bscscan.com'
}

//export const BASE_URL = 'http://localhost:3000'
export const BASE_URL = "https://bnbdisk.com"


export const connectorLocalStorageKey = "connectorIdv2"
export const walletLocalStorageKey = "wallet";

//export const provider = "https://data-seed-prebsc-1-s1.binance.org:8545"
export const provider = "https://bsc-dataseed.binance.org"
export const id = "salary"
export const cakeId = "tether"
export const currency = "usd"
export const contractAddress = "0x5fE07c8a5595432B3F89D643b485a24d1aaCF30A"