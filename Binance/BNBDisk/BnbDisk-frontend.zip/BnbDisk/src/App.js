import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { createBrowserHistory } from 'history'

import './App.css';
import Home from './pages/Home'
import Cart from './pages/Cart'
import SaleInfo from './pages/SaleInfo';
import Dashboard from './pages/admin/Dashboard'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" >
          <Route index element={<Home />} />
          <Route path="shop" element={<Cart />} />
          <Route path="sale">
            <Route path=":tokenId/:hash" element={<SaleInfo />} />
          </Route>
          <Route path="admin" element={<Dashboard />} />
          {/*<Route path="*" element={<Navigate replace to="/" />} />*/}
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App;
