export const TOKEN_ID = "tokenId"
export const TOKEN_HASH = "tokenHash"