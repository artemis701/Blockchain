import React from 'react'
import styled from 'styled-components';

const FooterContainer = styled.div`
    display: grid;
    grid-template-columns: 23% 23% 23% 23%;
`

const FooterItem = styled.div`
    //color: white;
    color: grey;
    font-size: 16px;
    line-height: 20px;
    margin-top: 15px;
    text-decoration:underline;
    cursor: pointer;
`

const Footer = () => {
    return (
        <FooterContainer>
            <FooterItem>Description and Rules</FooterItem>
            <FooterItem>Video Tutorial</FooterItem>
            <FooterItem>Contact Us</FooterItem>
            <FooterItem>BNBDisk scripts</FooterItem> 
        </FooterContainer>
    )
}

export default Footer;