import React from 'react';
import { styled } from '@mui/material/styles';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';

const BootstrapTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} arrow classes={{ popper: className }} />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.arrow}`]: {
      color: theme.palette.common.black,
    },
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: theme.palette.common.black,
      maxWidth: 250,
      opacity: 0.9,
      fontSize: "14px",
      textAlign: "center"
    },
  }));
  

const CustomTooltip = (props) => {
  const { title, placement } = props
  return (
      <BootstrapTooltip title={title} placement={placement} {...props}>
          {props.children}
      </BootstrapTooltip>
  )
}

export default CustomTooltip;