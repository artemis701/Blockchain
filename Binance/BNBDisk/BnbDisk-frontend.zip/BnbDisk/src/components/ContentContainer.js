import React from 'react'
import styled from 'styled-components'

const CustomContainer = styled.div`
    background-color: white;
	border-radius: 4px;
	box-shadow: 0 1px 2px #aaa;
	min-height: 300px;
	padding: 1rem;
`

const ContentContainer = (props) => {
    return (
        <CustomContainer>
            { props.children }
        </CustomContainer>
    )
}

export default ContentContainer