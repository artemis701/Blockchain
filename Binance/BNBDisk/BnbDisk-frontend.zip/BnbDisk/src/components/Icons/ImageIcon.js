import React from 'react';

const ImageIcon = (props) => {
    const { url } = props
    return (
        <>
            <img className="mr-2 mb-1" src={url} alt="BNB" width="20px" height="20px" />
        </>
    );
}

export default ImageIcon