import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import { Button } from '@mui/material'
import { styled as muiStyled } from '@mui/material/styles';
import { purple } from '@mui/material/colors';


import Toast from '../components/Toast';
import { setAddress } from '../state/Home'
import { ellipseAddress, getImageUrl } from '../utils'
import ContractUtils from '../utils/ContractUtils'


const HeaderContainer = styled.div`
    width: 100%;
    height: 50px;
    color: white;
    font-size: 30px;
    line-height: 50px;
    margin-bottom: 10px;
`

const Logo = styled.img`
    width: 30px;
    height: auto;
    margin-right: 8px;
    margin-bottom: 4px;
`

const ColorButton = muiStyled(Button)(({ theme }) => ({
    marginLeft: 20,
    color: theme.palette.getContrastText(purple[500]),
    backgroundColor: purple[500],
    '&:hover': {
      backgroundColor: purple[800],
    },
}));

const Header = (props) => {
    const { walletButton } = props
    const dispatch = useDispatch()
    const address = useSelector(state => state.home.address)
    
    const [ showToast, setShowToast ] = useState(false)
	const [ toastMessage, setToastMessage ] = useState("")
	const [ toastType, setToastType ] = useState(2) //1: success, 2: error
    
    const onClickConnect = async () => {
        let res = await ContractUtils.connectWallet();
        if(res.address) {
            setShowToast(true)
            setToastType(1)
            setToastMessage("Connected Successfully!")
            dispatch(setAddress({address: res.address}))
        }
        else{
            setShowToast(true)
            setToastType(2)
            setToastMessage(res.status)
        }
    }

    const onClickDisconnect = async () => {
        await ContractUtils.disconnectWallet();
        dispatch(setAddress({address: ""}))
    }

    const onToastClose = () => {
		setShowToast(false);
	}

    return (
        <HeaderContainer>
            <div style={{float:"right"}}>
                {/*<Logo src={getImageUrl("assets/images/logomotion.gif")} alt="logo" />*/}
                <Link className="header-link" to="/">BNBDisk</Link>
                { !walletButton ? (<></>) : (
                    address ? (
                        <ColorButton variant="contained" onClick={onClickDisconnect}>{ellipseAddress(address)}</ColorButton>
                    ):(
                        <ColorButton variant="contained" onClick={onClickConnect}>Connect</ColorButton>
                    )
                )}
            </div>
            <Toast
                open={showToast}
                message={toastMessage}
                handleClose={onToastClose}
                type={toastType}
            />
        </HeaderContainer>
    )
}

export default Header