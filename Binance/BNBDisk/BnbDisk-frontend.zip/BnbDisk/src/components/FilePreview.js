import React from 'react'
import styled from 'styled-components'

const styles = {
    main: {
        border: "1px dashed grey"
    },
    close: {
        float: 'right',
        marginRight: 10,
        cursor: 'pointer'
    }
}

const FileReview = (props) => {
    const { file, onUnselect } = props
    return (
        <div style={styles.main}>
            <b>{file.name}</b>
            <a style={styles.close} onClick={() => onUnselect(file)}>X</a>
        </div>
    )
}

export default FileReview