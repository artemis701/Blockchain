import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import styled from 'styled-components'
import { CopyToClipboard } from 'react-copy-to-clipboard';
import LinkIcon from '@mui/icons-material/Link';
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Button from '@mui/material/Button'
import Input from '@mui/material/Input'
import FileDownload from 'js-file-download'
import axios from 'axios'

import { TOKEN_HASH, TOKEN_ID } from '../constants'
import DefaultLayout from './Layout'
import ContentContainer from '../components/ContentContainer'
import Toast from '../components/Toast';
import ContractUtils from '../utils/ContractUtils';
import IPFSUtils from '../utils/IPFSUtils';
import { useSelector } from 'react-redux';
import { formatSize } from '../utils';

const PriceSpan = styled.span`
    color: #17a2b8!important;
`
const CountSpan = styled.span`
    color: #28a745!important;
`
const AlertDiv = styled.div`
    width: 100%;
`

const CustomInput = styled(Input)`
    background-color: white;
    border-radius: 5px;
    padding-left: 5px;
    margin-left: 0.5rem!important;
`

const SaleInfo = (props) => {
    const navigate = useNavigate()
    const address = useSelector(state => state.home.address)

    const [ dropText, setDropText ] = useState('Processing...')
    const [ isWaiting, setWaiting ] = useState(false)
    const [ showToast, setShowToast ] = useState(false)
	const [ toastMessage, setToastMessage ] = useState("")
	const [ toastType, setToastType ] = useState(2) //1: success, 2: error
    const [ toAddress, setToAddress ] = useState(address)
    const [ tokenData, setTokenData ] = useState({})

    //console.log("SaleInfo Params...")
    let { tokenId, hash: owner } = useParams()

    useEffect( async ()=>{
        if(isNaN(parseInt(tokenId))){
            navigate('/')
        }
        setDropText('Loading...')
        setWaiting(true)
        let res = await ContractUtils.getTokenURI(tokenId)
        // if(res.sucess) {
        //     setShowToast(true)
        //     setToastType(2)
        //     setToastMessage(res.status)
        //     return;
        // }
        let tokenURI = res.status
        res = await IPFSUtils.loadFromIPFS(tokenURI)
        if(res.status !== 200){
            setShowToast(true)
            setToastType(2)
            setToastMessage("Load from IPFS failed!")
            //console.log("LoadFromIPFS, res = ", res)
            return;
        }
        let contractRes = await ContractUtils.getAssetInfo(tokenId, owner)
        if(!contractRes.success){
            //console.log("GetInfoFrom Contract Failed: res = ", contractRes)
            //navigate('/')
            setShowToast(true)
            setToastType(2)
            setToastMessage(contractRes.status)
            setWaiting(false)
            return;
        }
        let data = {
            ...res.data,
            ...contractRes.status,
            tokenURI
        }
        //console.log("UseEffect: data = ", data)
        if(data.files == undefined) data.files = [];
        setWaiting(false);
        setTokenData(data)
    }, [])
    useEffect(() => {
        setToAddress(address)
    }, [address])
    
    const onToastClose = () => {
		setShowToast(false);
	}

    const onClickBuy = async (e) => {
        if(!toAddress){
            setShowToast(true);
            setToastMessage("Connect Wallet")
            return;
        }
        setDropText('Processing...')
        setWaiting(true)
        let price = tokenData.bnbVal * Math.pow(10, ContractUtils.getBNBDecimals());
        //console.log("Price: ", price)
        if(isNaN(price)){
            setShowToast(true)
            setToastType(2)
            setToastMessage("Nothing to buy!");
            setWaiting(false)
            return;
        }
        let res = await ContractUtils.buyNFT(tokenId, owner, price);
        setWaiting(false)
        //console.log("res:", res)
        if(res.success){
            //console.log("tokenId: ", tokenId, " tokenURI:" ,tokenData.tokenURI)
            setShowToast(true)
            setToastType(1)
            setToastMessage("Success!");
        }else{
            setShowToast(true)
            setToastType(2)
            setToastMessage(res.status);
        }
    }
    const onClickDownload = async () => {
        if(!toAddress){
            setShowToast(true);
            setToastMessage("Connect Wallet")
            return;
        }
        setDropText('Downloading...')
        setWaiting(true)
        let res = await ContractUtils.isPurchased(tokenId, address);
        //console.log("onClickDownload, res = ", res)
        if(res.success && res.status){
            for(let i = 0;i<tokenData.files.length;i++){
                await axios.get(tokenData.files[i], {responseType: 'blob'}).then(res => {
                    FileDownload(res.data, tokenData.fileInfo[i].name);
                })
            }
        }else if(res.success && !res.status){
            setShowToast(true);
            setToastType(2)
            setToastMessage("You can't download file. Purchase first!")
        } else{
            setShowToast(true);
            setToastType(2)
            setToastMessage(res.status)
        }
        setWaiting(false)
    }
    const onClickCopy = () => {
        if(toAddress){
            setShowToast(true)
            setToastType(1)
            setToastMessage("Copied!")
        }
        
    }
    //console.log("tokenData:", tokenData)
    return (
        <DefaultLayout walletButton={true}>
            <ContentContainer>
                <div className='text-center mb-4'><h2>Volumne Created</h2></div>
                <div className="row">
                    <div className='col-6'>
                        <PriceSpan><h4>Price: {tokenData.bnbVal} BNB</h4></PriceSpan><br/>
                        <CountSpan><h5>Count: {tokenData.limit?'No limit':tokenData.saleCount}</h5></CountSpan><br/>
                        <b>Total: {tokenData.files && tokenData.files.length} file(s)</b> <br/>
                        <b>Hidden text contain: {tokenData.saleText && tokenData.saleText.length} symbol(s)</b><br/>
                        Download file(s): <br/>
                        <ul>
                            {tokenData.files && tokenData.fileInfo.map((file) => {
                                return (<li key={file.name}>
                                    {file.name + " - " + formatSize(file.size)}
                                </li>)
                            })}
                        </ul>
                    </div>
                    <div className='col-6'>
                        <b>Info(Description by file owner):</b><br/>
                        <strong className="text-muted">{tokenData.fileInfoText}</strong>
                    </div>
                </div>
                <div className="row">
                    <div className='col-12 mb-3 mt-3'>
                        <AlertDiv className="alert alert-primary">
                            <div style={{display:'flex', justifyContent: 'space-between'}}>
                                <div style={{wordWrap: 'break-word'}}>
                                    Address: <CopyToClipboard text={toAddress} onCopy={onClickCopy}>
                                        <CustomInput value={toAddress} style={{width: "430px"}} onChange={(e) => setToAddress(e.target.value)} />
                                    </CopyToClipboard>
                                </div>
                                <div>
                                    <Button variant="contained" color="error" className="mr-3" onClick={onClickDownload}><FileDownloadOutlinedIcon /> Download</Button>
                                    <Button variant="contained" color="success" style={{float: 'right'}} onClick={onClickBuy}><ShoppingCartOutlinedIcon/> Buy</Button>
                                </div>
                            </div>
                        </AlertDiv>
                    </div>
                </div>
                <Backdrop
					sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
					open={isWaiting}
				>
					<CircularProgress color="inherit" />
					<span style={{marginLeft: 10}}>{dropText}</span>
				</Backdrop>
                <Toast
					open={showToast}
					message={toastMessage}
					handleClose={onToastClose}
					type={toastType}
				/>
            </ContentContainer>
        </DefaultLayout>
    )
}

export default SaleInfo