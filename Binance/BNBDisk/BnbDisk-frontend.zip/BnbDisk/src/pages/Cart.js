import React, { useState, useEffect } from 'react'
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import styled from 'styled-components'
import LinkIcon from '@mui/icons-material/Link';
import ContentCopyRoundedIcon from '@mui/icons-material/ContentCopyRounded';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Button from '@mui/material/Button'

import DefaultLayout from './Layout'
import ContentContainer from '../components/ContentContainer'
import Toast from '../components/Toast';

import { TOKEN_HASH, TOKEN_ID } from '../constants'
import { BASE_URL } from '../config'
import IPFSUtils from '../utils/IPFSUtils';
import ContractUtils from '../utils/ContractUtils';
import { formatSize } from '../utils';


const PriceSpan = styled.span`
    color: #17a2b8!important;
`
const AlertDiv = styled.div`
    width: 100%;
`

const Cart = (props) => {
    const navigate = useNavigate()
    const address = useSelector(state => state.home.address)
    
    const [ isWaiting, setWaiting ] = useState(false)
    const [ showToast, setShowToast ] = useState(false)
	const [ toastMessage, setToastMessage ] = useState("")
	const [ toastType, setToastType ] = useState(2) //1: success, 2: error
    const [ tokenId, setTokenId ] = useState()
    const [ tokenData, setTokenData ] = useState({})
    //const { files, saleText, bnbVal, seller, saleCount } = props
    useEffect(async () => {
        //console.log("Cart: useEffect----------------")
        const tId = window.localStorage.getItem(TOKEN_ID)
        const hash = window.localStorage.getItem(TOKEN_HASH)
        //window.localStorage.removeItem(TOKEN_ID)
        if(tId === null){
            navigate('/')
        }
        setTokenId(tId)
        setWaiting(true)
        //console.log("LoadFromIPFS , hash = ", hash)
        let res = await IPFSUtils.loadFromIPFS(hash)
        //console.log("Cart-LoadFromIPF, res = ",res)
        if(res.status !== 200) navigate('/')
        let contractRes = await ContractUtils.getAssetInfo(tId, address);
        //console.log("LoadFromContract-getAssetInfo: res = ", contractRes)
        if(!contractRes.success) navigate('/')
        let data = {
            ...res.data,
            ...contractRes.status
        }
        if(data.files == undefined)
            data.files = [];
        //console.log("Cart-TokenData: data = ", data)
        setWaiting(false)
        setTokenData(data)
    }, [])

    const onToastClose = () => {
		setShowToast(false);
	}

    const onClickCopy = () => {
        setShowToast(true)
        setToastType(1)
        setToastMessage("Copied!")
    }
    return (
        <DefaultLayout walletButton={false}>
            <ContentContainer>
                <div className='text-center mb-4'><h2>Volumne Created</h2></div>
                <div className="row">
                    {tokenData.files ? (
                    <div className={'col-6' + (tokenData.files.length?"":" hidden")}>
                        <b>Total: {tokenData.files.length} file(s)</b><br/><br/>
                        Uploaded:<br/>
                        <ul>
                            {tokenData.files && tokenData.fileInfo.map((file) => {
                                return (<li key={file.name}>
                                    {file.name + " - " + formatSize(file.size)}
                                </li>)
                            })}
                        </ul>
                    </div>
                    ):(<></>)}
                    <div className='col-6'>
                        {tokenData.saleText && tokenData.saleText.length!=0? ( <b>Text Contain: {tokenData.saleText.length} symbol(s)</b> ):( <></> ) }<br/><br/>
                        <PriceSpan><h4>Price: {tokenData.bnbVal} BNB</h4></PriceSpan><br/>
                        Address of seller:<br/>
                        <b>{address}</b><br/>
                        Sale Count: {tokenData.limit?'No limit':tokenData.saleCount} time(s)
                    </div>
                </div>
                <div className="row">
                    <div className='col-12 mb-3 mt-3'>
                        <AlertDiv className="alert alert-primary">
                            <p className="text-muted">
                                Please copy and save the link below. Otherwise, you will have to upload the file(s) and write text again. Share this link directly to buyers. Publish at social networks, messenger channel, forum, blog, site, etc...
                            </p>
                            <div style={{display:'flex', justifyContent: 'space-between'}}>
                                <div style={{wordWrap: 'break-word'}}>
                                    <LinkIcon />
                                    <a href={BASE_URL + "/sale/" + tokenId + "/" + address} style={{marginLeft: 8, fontSize: "18px"}}>{BASE_URL + "/sale/" + tokenId + "/" + address}</a>
                                </div>
                                <div>
                                    <CopyToClipboard text={BASE_URL + "/sale/" + tokenId + "/" + address}
                                        onCopy={onClickCopy}
                                    >
                                        <Button variant="contained" color="success" style={{float: 'right'}}><ContentCopyRoundedIcon/> Copy</Button>
                                    </CopyToClipboard>
                                </div>
                            </div>
                        </AlertDiv>
                    </div>
                    
                </div>
                <div className="row">
                    <div className="col-12 text-center">
                        <h5>Share this volume with your friends</h5>
                    </div>
                </div>
                <Backdrop
					sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
					open={isWaiting}
				>
					<CircularProgress color="inherit" />
					<span style={{marginLeft: 10}}>Processing...</span>
				</Backdrop>
                <Toast
					open={showToast}
					message={toastMessage}
					handleClose={onToastClose}
					type={toastType}
				/>
            </ContentContainer>
        </DefaultLayout>
    )
}

export default Cart