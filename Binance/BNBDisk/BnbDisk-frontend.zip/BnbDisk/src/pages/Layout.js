import React from 'react'
import styled from 'styled-components'

import Header from '../components/Header';
import Footer from '../components/Footer';


const Container = styled.div`
	width: 80%;
	min-width: 600px;
	margin: 0 auto;
`

const DefaultLayout = (props) => {
    const { walletButton } = props
    return (
        <Container>
            <Header walletButton={walletButton} />
            {props.children}
            {/*<Footer />*/}
        </Container>
    )
}

export default DefaultLayout