import React, { useState, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import ToggleButton from '@mui/material/ToggleButton';
import TextField from '@mui/material/TextField';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import styled from 'styled-components';

import { setTokenId } from '../state/Home';

import DefaultLayout from './Layout'
import ContentContainer from '../components/ContentContainer';
import DragAndDrop from '../components/DragAndDrop';
import FileReview from '../components/FilePreview';
import CustomTooltip from '../components/CustomTooltip';
import Toast from '../components/Toast';

import { TOKEN_HASH, TOKEN_ID } from '../constants'
import ContractUtils from '../utils/ContractUtils'
import IPFSUtils from '../utils/IPFSUtils';

const FlexContent = styled.div`
	display: flex;
`
const Text = styled.p`
	color: #868e96;
	margin: 0;
`

const TextArea = styled.textarea`
	resize: none;
	overflow-y: scroll;
`
const PrettoSlider = styled(Slider)({
    color: '#52af77',
    height: 8,
    '& .MuiSlider-track': {
	//backgroundColor: '#52af77',
      border: 'none',
    },
    '& .MuiSlider-thumb': {
      height: 12,
      width: 12,
 //     backgroundColor: '#52af77',
      border: '2px solid currentColor',
      '&:focus, &:hover, &.Mui-active, &.Mui-focusVisible': {
        boxShadow: 'inherit',
      },
      '&:before': {
        display: 'none',
      },
    },
    '& .MuiSlider-valueLabel': {
      lineHeight: 1.2,
      fontSize: 10,
      background: 'unset',
      padding: 0,
      width: 18,
      height: 18,
      borderRadius: '50% 50% 50% 0',
      backgroundColor: '#1976d2',
      transformOrigin: 'bottom left',
      transform: 'translate(50%, -100%) rotate(-45deg) scale(0)',
      '&:before': { display: 'none' },
      '&.MuiSlider-valueLabelOpen': {
        transform: 'translate(50%, -100%) rotate(-45deg) scale(1)',
      },
      '& > *': {
        transform: 'rotate(45deg)',
      },
    },
});

const FileDropZone = styled.div`
	position: relative;
	min-height: 180px;
	max-height: 490px;
	overflow-y: hidden;
	width: inherit;
	border-radius: 6px;
	border: 1px dashed #ccc;
	background-color: #fafafa;
	padding: 20px;

`
const DropText = styled.div`
	text-align: center;
    font-size: 32px;
    color: #cccccc;
    margin-top: 10px;
`

const styles = {
	label: {
		lineHeight: "40px",
		marginRight: "10px"
	}
}

const marks = [
	{
	  value: 0,
	  label: '0',
	},
	{
	  value: 25,
	  label: '25',
	},
	{
	  value: 50,
	  label: '50',
	},
	{
		value: 75,
		label: '75',
	},
	{
	  value: 100,
	  label: '100',
	},
];


const Home = () => {
	const navigate = useNavigate()

	const bnbDecimals = ContractUtils.getBNBDecimals()

	const address = useSelector(state => state.home.address)

	const [ isWaiting, setWaiting ] = useState(false)
	const [ showToast, setShowToast ] = useState(false)
	const [ toastMessage, setToastMessage ] = useState("")
	const [ toastType, setToastType ] = useState(2) //1: success, 2: error
	const [ files, setFiles] = useState([])
	const [ saleText, setSaleText ] = useState("")
	const [ fileInfoText, setFileInfoText ] = useState("")
	const [ bnbVal, setBNBVal ] = useState(0)
	const [ usdVal, setUSDVal ] = useState(0)
	//const [ type, setType] = useState('BNB')
	//const [ rate, setRate ] = useState(590.3)
	const [ saleCount, setSaleCount ] = useState(1)

	const fileInput = useRef("fileInput")

	//const handleType = (e, newType) => {
	//	setType(newType);
	//};

	const onToastClose = () => {
		setShowToast(false);
	}

	const handleDrop = (newFiles) => {
		let fileList = files;
		for(let i = 0;i<newFiles.length;i++){
			if(!newFiles[i].name) return
			let j;
			for(j = 0;j<fileList.length;j++)
				if(fileList[j].name === newFiles[i].name)
					break;
			if(j==fileList.length)
				fileList.push(newFiles[i])
		}
		setFiles(fileList)
	}

	const onUploadClick = () => {
		fileInput.current.click()
	}

	const onFileSelected = (e) => {
		const selFiles = e.target.files
		handleDrop(selFiles)
	}

	const onFileUnSelected = (delFile) => {
		//console.log("onFileUnSelected")
		//console.log(delFile)
		let fileList = [];

		for(let i = 0;i<files.length;i++)
			if(files[i] != delFile.name)
				fileList.push(files[i])
		setFiles(fileList)
	}

	const onBNBValChange = (e) => {
		setBNBVal(e.target.value)
	}

	const onUSDValChange = (e) => { } //not used yet

	const onUploadShareClick = async (e) => {
		e.preventDefault()
		if(!address)
		{
			//alert("Connect your Wallet!")
			setShowToast(true);
			setToastMessage("Connect your Wallet!")
			setToastType(2)
			return
		}else if(files.length==0 && !saleText) {
			//alert("Nothing to sale!")
			setShowToast(true);
			setToastMessage("Nothing to sale!")
			setToastType(2)
			return
		}else if(bnbVal == 0) {
			//alert("Price cannot be zero!")
			setShowToast(true);
			setToastMessage("Price cannot be zero!")
			setToastType(2)
			setBNBVal(0.001)
			return
		}
		let fileInfo = [];
		let totalSize = 0
		for(let i = 0; i<files.length;i++){
			fileInfo.push({
				name: files[i].name,
				size: files[i].size,
				type: files[i].type
			})
			totalSize += files[i].size;
		}
		if(totalSize > 50 * 1024 * 1024) //50 MB
		{
			setShowToast(true);
			setToastMessage("FileSize Cannot be bigger than 50MB!!!")
			setToastType(2)
			return
		}
		setWaiting(true)
		const hashLists = await IPFSUtils.uploadFileToIPFS(files)
		if(files.length && !hashLists.length) {
			setShowToast(true);
			setToastMessage("Uploading to IPFS failed!")
			setToastType(2)
			return
		}
		
		const data = {
			address,
			files: hashLists,
			fileInfo,
			saleText,
			fileInfoText
		}
		const hash = await IPFSUtils.uploadTextToIPFS(data)
		//tokenHash, price, count
		let price = bnbVal * Math.pow(10, bnbDecimals);
		let res = await ContractUtils.mintNFT(address, hash, price, saleCount );
		//console.log("Home-mintNFT: res = ", res)
		setWaiting(false)
		if(res.success){
			setShowToast(true);
			setToastType(1)
			setToastMessage("Uploaded Successfully!");
			let newTokenId = parseInt(res.status);
			window.localStorage.setItem(TOKEN_ID, newTokenId)
			window.localStorage.setItem(TOKEN_HASH, hash)
			navigate('/shop')
		}else{
			setShowToast(true);
			setToastMessage(res.status);
			setToastType(2)
		}
		
	}

	return (
		<DefaultLayout walletButton={true}>
			<ContentContainer>
				<div><h1>Upload, share and sale for BNB</h1></div>
				<FlexContent className="row">
					<div className='col-lg-6 col-md-6'>
						<Text>Upload any files (max file size 50MB):</Text>
						<DragAndDrop handleDrop={handleDrop}>
							<CustomTooltip
								title="Drag and drop files in any format and language. Also you can drag folder. But will be uploaded contained files only, without folder."
								placement="top"
							>
								<FileDropZone>
									<Button variant="contained" onClick={onUploadClick}>Upload a file</Button><br/>
									<input type="file" onChange={onFileSelected} ref={fileInput} multiple hidden />
									{files.length ? (files.map((file) => {	

										return <FileReview onUnselect={onFileUnSelected} key={file.name} file={file} />
									}									
									)):(
										<DropText>
											Drop Here
										</DropText>
									)}
								</FileDropZone>
							</CustomTooltip>
						</DragAndDrop>
					</div>
					<div className='col-lg-6 col-md-6'>
						<Text>or text for sale:</Text>
						<CustomTooltip
							title="You can sale text only without any files. Or sale files+text. As you wish. Max text lenght: 64kb."
							placement="top"
						>
							<TextArea className="form-control" name="symbols" rows="7" data-toggle="tooltip" data-placement="top"
							title=""
							data-original-title="You can sale text only without any files. Or sale files+text. As you wish. Max text lenght: 64kb."
							onChange={(e)=>setSaleText(e.target.value)}
							value={saleText}
							></TextArea>
						</CustomTooltip>
					</div>
				</FlexContent>
			</ContentContainer>
			<ContentContainer style={{marginTop: '1rem'}}>
				<FlexContent className='row'>
					<div className='col-lg-6 col-md-6'>
						<Text>Open info about your files (optional): </Text>
						<CustomTooltip
							title="Buyers will pay faster If have more seller's info and reputation."
							placement="top"
						>
							<TextArea className="form-control" title="" name="openinfo" rows="12" data-toggle="tooltip" data-placement="top"
							placeholder={"What you sale:"+"\n\n"+"Short description:" + "\n\nContact info:"+"\n\nemail, phone, social media, jabber, etc."}
							data-original-title="Buyers will pay faster If have more seller's info and reputation."
							onChange={(e) => setFileInfoText(e.target.value)}
							value={fileInfoText}
							></TextArea>
						</CustomTooltip>
					</div>
					<div className='col-lg-6 col-md-6'>
						<div className="form-group">
							<Text>Your Wallet Address<span className="text-danger">*</span></Text>
							<CustomTooltip
								title="Required field. Please make sure you enter and double-checked the right yours Wallet address to receive payment. (neither wallet address nor another same format address)"
								placement="top"
							>
								<input type="text" name="wallet-address" className="form-control" placeholder="" required="" title="" readOnly value={address} />
							</CustomTooltip>
						</div>
						<div className="row">
							<p className="col-12 text-muted m-sm-0">Price<span className="text-danger">*</span>:</p>
							<div className="col-lg-5 mt-3">
								<div className="input-group form-group">
									<div style={styles.label}>BNB</div>
									<CustomTooltip
										title="Required field. You will receive BNB only."
										placement="top"
									>
										<input name="price" type="number" className="form-control"
											min="0.000" step="0.001"
											onChange={onBNBValChange}
											value={bnbVal}
											/*disabled={ type === "BNB" ? true : false }*/
											maxLength="17" title=""/>
									</CustomTooltip>
								</div>
							</div>
							<div className="col-lg-5 col-md-5 col-sm-5 col-xs-5" hidden>
								<div className="input-group form-group">
									<div style={styles.label}>$</div>
									<input name="usd" type="price" className="form-control"
										onChange={onUSDValChange}
										value={usdVal}
										/*disabled={type === "USD" ? true : false }*/
										maxLength="10" data-toggle="tooltip" data-placement="top" title="" data-original-title="Amount in USD will be calculated into BNB and store. We accept BNB and forward to yours wallet."/>
								</div>
							</div>
							{/*<div className="col-12 text-center mt-2">
								<ToggleButtonGroup
									value={type}
									onChange={handleType}
									exclusive
									fullWidth={true}
									size="small"
									color={'secondary'}
									hidden
								>
									<ToggleButton variant="contained" color="primary" value="BNB">Fix Price in BNB</ToggleButton>
									<ToggleButton value="USD">Fix Price in USD</ToggleButton>
								</ToggleButtonGroup>
							</div>*/}
							<div className="col-12">
								<CustomTooltip
									title="Count of sales is the quantity limit. Choose 'zero' to sale unlimited times."
									placement="top"
								>
									<Text className="mb-4 mt-3">Count of Sales (Zero is an unlimited Sales):</Text>
								</CustomTooltip>
								<Box sx={{width: '90%'}} className="text-center">
									<PrettoSlider
										aria-label="NFT Count"
										defaultValue={1}
										value={ saleCount }
										onChange={(e) => setSaleCount(e.target.value)}
										step={1}
										valueLabelDisplay="on"
										marks={marks}
									/>
								</Box>
							</div>
						</div>
					</div>
					<div className="col-lg-12 text-center mt-4">
						<input name="filenames" type="text" hidden={true} />
						<input name="filedirnames" type="text" hidden={true} />
						<Button variant="contained" onClick={onUploadShareClick}>Upload and Share</Button>
					</div>
				</FlexContent>
				<Backdrop
					sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
					open={isWaiting}
				>
					<CircularProgress color="inherit" />
					<span style={{marginLeft: 10}}>Uploading...</span>
				</Backdrop>
				<Toast
					open={showToast}
					message={toastMessage}
					handleClose={onToastClose}
					type={toastType}
				/>
			</ContentContainer>
		</DefaultLayout>
	)
}

export default Home;