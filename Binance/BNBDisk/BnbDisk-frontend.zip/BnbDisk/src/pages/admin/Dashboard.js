import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import styled from 'styled-components'
import { Input } from '@mui/material'
import Button from '@mui/material/Button'
import ContentContainer from '../../components/ContentContainer'
import Toast from '../../components/Toast';
import DefaultLayout from '../Layout'
import ContractUtils from '../../utils/ContractUtils'


const CustomInput = styled(Input)`
    background-color: white;
    border: 1px solid black;
    border-radius: 5px;
    padding-left: 5px;
    margin-left: 0.5rem!important;
`

const Dashboard = () => {

    const address = useSelector(state => state.home.address)

    const [ fee, setFee ] = useState(0)
    const [ owner, setOwner ] = useState('')
    const [ showToast, setShowToast ] = useState(false)
	const [ toastMessage, setToastMessage ] = useState("")
	const [ toastType, setToastType ] = useState(2) //1: success, 2: error

    useEffect(async () => {
        let res = await ContractUtils.getTaxFee();
        if(res.success)
            setFee(res.status)
        else
            setFee(0)
    }, [])

    const onToastClose = () => {
		setShowToast(false);
	}

    const onClickSetFee = async () => {
        if(!address){
            setShowToast(true)
            setToastMessage("Connect to Wallet")
            return
        }
        if(fee < 0 || fee > 20) {
            setShowToast(true)
            setToastMessage("Fee can be between 0 and 20")
            setFee(0)
            return
        }
        let res = await ContractUtils.setTaxFee(fee)
        setShowToast(true)
        if(res.success)
            setToastMessage("Set Fee success")
        else
            setToastMessage(res.status)
    }
    const onClickTransferOwnership = async () => {
        if(!address){
            setShowToast(true)
            setToastMessage("Connect to Wallet")
            return
        }
        if(!owner){
            setShowToast(true)
            setToastMessage("Input param correctly!")
            return;
        }
        let res = await ContractUtils.transferOwnership(owner)
        //console.log("transfer, res = ", res)
        setShowToast(true)
        if(res.success)
            setToastMessage("TransferOwnership success")
        else
            setToastMessage(res.status)
    }
    const onClickWithdraw = async () => {
        if(!address){
            setShowToast(true)
            setToastMessage("Connect to Wallet")
            return
        }
        //console.log("onClickWithdraw")
        let res = await ContractUtils.withdraw()
    }
    return (
        <DefaultLayout walletButton={true}>
            <ContentContainer>
                <div className='row'>
                    <div className="col-2">Fee:</div>
                </div>
                <div className="row">
                    <CustomInput className="ml-5 mt-2" value={fee} type="number" step="1" min="0" max="20" onChange={(e) => setFee(e.target.value)} />
                    <Button className="ml-3 mt-2" variant="contained" color="success" onClick={onClickSetFee}> SET </Button>
                </div>
                <div className='row mt-2'>
                    <div className="col-2">Transfer Ownership:</div>
                </div>
                <div className="row">
                    <CustomInput className="ml-5 mt-2" style={{width: "430px"}} value={owner} onChange={(e) => setOwner(e.target.value)}/>
                    <Button className="ml-3 mt-2" variant="contained" color="success" onClick={onClickTransferOwnership}> Transfer </Button>
                </div>
                <div className='row mt-2'>
                    <div className="col-2">Withdraw:</div>
                </div>
                <div className="row">
                    <Button className="ml-3 mt-2" variant="contained" color="success" onClick={onClickWithdraw}> Withdraw </Button>
                </div>
                <Toast
					open={showToast}
					message={toastMessage}
					handleClose={onToastClose}
					type={toastType}
				/>
            </ContentContainer>
        </DefaultLayout>
    )
}

export default Dashboard