// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
import { ethers, upgrades } from "hardhat";
import { Contract } from "hardhat/internal/hardhat-network/stack-traces/model";
import { NFTCollectionManager } from "../typechain";

async function main() {
  console.log('Deploying NFTCollectionManager...');
  const contractFactory = await ethers.getContractFactory('NFTCollectionManager');
  const contract = await contractFactory.deploy();

  await contract.deployed();
  console.log("Contract deployed to:", contract.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1; 
}); 

// BSC Testnet Deployed
// 0x4Ad73320D323F9BFACF2cB29C218B2bB6048Ba9a
// 0xF36a8B804590877633BC0C6a8B9ae995929c754d
// 0x406B6df9130D86BE3a0C2A730724f0bb13602cB8
// 0x0D10C68F52326C47Dfc3FDBFDCCb37e3b8C852Cb
// 0x67F65795bCCAefA6F8452F1Fb153428fD40209a1

// Final 
// 0x28c0bA86370C1f566f6e1926E2f7f3d4A2426683


// Cronos Mainnet
